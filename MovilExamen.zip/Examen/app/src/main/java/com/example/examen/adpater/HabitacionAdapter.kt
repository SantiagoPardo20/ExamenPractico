package com.example.examen.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.examen.R
import com.example.examen.model.Habitacion

class HabitacionAdapter(private val habitaciones: List<Habitacion>) :
    RecyclerView.Adapter<HabitacionAdapter.HabitacionViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HabitacionViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_habitacion, parent, false)
        return HabitacionViewHolder(view)
    }

    override fun onBindViewHolder(holder: HabitacionViewHolder, position: Int) {
        val habitacion = habitaciones[position]
        holder.bind(habitacion)
    }

    override fun getItemCount(): Int = habitaciones.size

    class HabitacionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val numhabitacion: TextView = itemView.findViewById(R.id.numhabitacion)
        private val descripcion: TextView = itemView.findViewById(R.id.descripcion)
        private val precio: TextView = itemView.findViewById(R.id.precio)
        private val estado: TextView = itemView.findViewById(R.id.estado)

        fun bind(habitacion: Habitacion) {
            numhabitacion.text = habitacion.numhabitacion.toString()
            descripcion.text = habitacion.descripcion
            precio.text = habitacion.precio.toString()
            estado.text = habitacion.estado
        }
    }
}
