package com.example.examen.model


data class Habitacion(
    val id: Long,
    val numhabitacion: Int,
    val tipo: TipoHabitacion,
    val descripcion: String,
    val precio: Double,
    val estado: String
)

data class TipoHabitacion(
    val id: Long,
    val nombre: String
)
