package com.example.examen.conexion

import com.example.examen.model.Habitacion
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
        @GET("api/habitaciones")
        fun getHabitaciones(): Call<List<Habitacion>>
}
