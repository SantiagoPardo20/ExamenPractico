package com.example.examen

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.examen.adapter.HabitacionAdapter
import com.example.examen.model.Habitacion
import com.example.examen.conexion.RetrofitInstance
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: androidx.recyclerview.widget.RecyclerView
    private lateinit var adapter: HabitacionAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerViewHabitaciones)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = HabitacionAdapter(emptyList())
        recyclerView.adapter = adapter

        val buttonActualizar: Button = findViewById(R.id.buttonActualizar)
        buttonActualizar.setOnClickListener {
            fetchHabitaciones()
        }

        // Fetch data when the activity is created
        fetchHabitaciones()
    }

    private fun fetchHabitaciones() {
        RetrofitInstance.apiService.getHabitaciones().enqueue(object : Callback<List<Habitacion>> {
            override fun onResponse(call: Call<List<Habitacion>>, response: Response<List<Habitacion>>) {
                if (response.isSuccessful) {
                    val habitaciones = response.body() ?: emptyList()
                    adapter = HabitacionAdapter(habitaciones)
                    recyclerView.adapter = adapter
                }
            }

            override fun onFailure(call: Call<List<Habitacion>>, t: Throwable) {
                // Manejar el error
            }
        })
    }
}
