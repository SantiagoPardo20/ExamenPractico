package com.exa.service;

import com.exa.model.Habitacion;
import java.util.List;

public interface IHabitacionService {
    List<Habitacion> findAll();
    Habitacion findOne(Long id);
    Habitacion save(Habitacion habitacion);
    void delete(Long id);
}
