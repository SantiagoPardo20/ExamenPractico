package com.exa.service;

import java.util.List;

import com.exa.model.TipoHabitacion;


public interface ITipoHabitacionService {
    public List<TipoHabitacion> findAll();
    public TipoHabitacion findOne(Long id);
}
