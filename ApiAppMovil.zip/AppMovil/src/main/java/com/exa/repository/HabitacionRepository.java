package com.exa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exa.model.Habitacion;



public interface HabitacionRepository extends JpaRepository<Habitacion, Long> {
 List<Habitacion> findByNumhabitacionAndTipoNombreContainingIgnoreCaseAndEstadoContainingIgnoreCaseAndPrecio(int numhabitacion, String tipoNombre, String estado, Double precio);
 List<Habitacion> findByNumhabitacion(int numhabitacion);
 List<Habitacion> findByTipoNombreContainingIgnoreCase(String tipoNombre);
 List<Habitacion> findByEstadoContainingIgnoreCase(String estado);
 List<Habitacion> findByPrecio(Double precio);
}
