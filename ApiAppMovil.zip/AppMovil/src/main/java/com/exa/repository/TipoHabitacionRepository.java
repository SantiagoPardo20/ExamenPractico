package com.exa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.exa.model.TipoHabitacion;


public interface TipoHabitacionRepository extends JpaRepository<TipoHabitacion, Long> {
}
