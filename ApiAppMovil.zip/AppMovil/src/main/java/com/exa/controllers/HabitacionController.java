package com.exa.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.exa.model.Habitacion;
import com.exa.service.IHabitacionService;

@RestController
@RequestMapping("/api/habitaciones")
public class HabitacionController {

    @Autowired
    private IHabitacionService habitacionService;

    // Listar todas las habitaciones
    @GetMapping
    public List<Habitacion> listar() {
        return habitacionService.findAll();
    }


}
