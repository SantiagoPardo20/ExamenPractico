INSERT INTO usuarios (email, password, rol) VALUES ('admin@gmail.com', '$2a$10$VTP2Ri3C1VjCzV19Xdj6qetD/54L6NE6VR3gMXhOMpOFbzoEIZeG2', 'ADMIN');
