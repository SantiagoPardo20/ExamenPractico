package com.examen.servicio;

import com.examen.modelo.Habitacion;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.property.TextAlignment;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.springframework.stereotype.Service;

@Service
public class ReporteService {

    public ByteArrayInputStream generarReporte(List<Habitacion> habitaciones) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdfDoc = new PdfDocument(writer);
        Document document = new Document(pdfDoc);

        // nombre de la empresa
        Paragraph empresa = new Paragraph("HOTEL HOWARD JOHNSON")
                .setTextAlignment(TextAlignment.CENTER)
                .setBold()
                .setFontSize(18);
        document.add(empresa);

        // título para el reporte
        Paragraph titulo = new Paragraph("Reporte de HABITACIONES")
                .setTextAlignment(TextAlignment.CENTER)
                .setFontSize(16)
                .setBold();
        document.add(titulo);

        // Añadir un espacio
        document.add(new Paragraph("\n"));

        // Crear una tabla con 5 columnas
        Table table = new Table(6);
        table.addCell(new Cell().add(new Paragraph("ID")).setBold());
        table.addCell(new Cell().add(new Paragraph("# Habitación")).setBold());
        table.addCell(new Cell().add(new Paragraph("Tipo")).setBold());
        table.addCell(new Cell().add(new Paragraph("Descripción")).setBold());
        table.addCell(new Cell().add(new Paragraph("Precio")).setBold());
        table.addCell(new Cell().add(new Paragraph("Estado")).setBold());

        // Añadir las habitaciones a la tabla
        for (Habitacion habitacion : habitaciones) {
            table.addCell(new Cell().add(new Paragraph(habitacion.getId().toString())));
            table.addCell(new Cell().add(new Paragraph(String.valueOf(habitacion.getNumhabitacion())))); 
            table.addCell(new Cell().add(new Paragraph(habitacion.getTipo().getNombre()))); // Mostrar el nombre del tipo
            table.addCell(new Cell().add(new Paragraph(habitacion.getDescripcion())));
            table.addCell(new Cell().add(new Paragraph(habitacion.getPrecio().toString())));
            table.addCell(new Cell().add(new Paragraph(habitacion.getEstado())));
        }

        // Añadir la tabla al documento
        document.add(table);

        // Cerrar el documento
        document.close();

        return new ByteArrayInputStream(out.toByteArray());
    }
}
