package com.examen.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.examen.modelo.Habitacion;
import com.examen.repositorio.HabitacionRepository;

@Service
public class HabitacionServiceImpl implements IHabitacionService {

    @Autowired
    private HabitacionRepository habitacionRepository;

    @Transactional(readOnly = true)
    @Override
    public List<Habitacion> findAll() {
        return habitacionRepository.findAll();
    }

    @Transactional
    @Override
    public void save(Habitacion habitacion) {
        habitacionRepository.save(habitacion);
    }

    @Transactional(readOnly = true)
    @Override
    public Habitacion findOne(Long id) {
        return habitacionRepository.findById(id).orElse(null);
    }

    @Transactional
    @Override
    public void delete(Long id) {
        habitacionRepository.deleteById(id);
    }
 // HabitacionServiceImpl.java
    @Transactional(readOnly = true)
    @Override
    public List<Habitacion> findByBusqueda(int numhabitacion, String tipoNombre, String estado, Double precio) {
        if (numhabitacion > 0 && tipoNombre != null && !tipoNombre.isEmpty() && estado != null && !estado.isEmpty() && precio != null) {
            return habitacionRepository.findByNumhabitacionAndTipoNombreContainingIgnoreCaseAndEstadoContainingIgnoreCaseAndPrecio(
                numhabitacion, tipoNombre, estado, precio);
        } else if (numhabitacion > 0) {
            return habitacionRepository.findByNumhabitacion(numhabitacion);
        } else if (tipoNombre != null && !tipoNombre.isEmpty()) {
            return habitacionRepository.findByTipoNombreContainingIgnoreCase(tipoNombre);
        } else if (estado != null && !estado.isEmpty()) {
            return habitacionRepository.findByEstadoContainingIgnoreCase(estado);
        } else if (precio != null) {
            return habitacionRepository.findByPrecio(precio);
        } else {
            return findAll();
        }
    }


}

