package com.examen.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.examen.modelo.TipoHabitacion;
import com.examen.repositorio.TipoHabitacionRepository;

@Service
public class TipoHabitacionServiceImpl implements ITipoHabitacionService {

    @Autowired
    private TipoHabitacionRepository tipoHabitacionRepositorio;

    @Transactional(readOnly = true)
    @Override
    public List<TipoHabitacion> findAll() {
        return tipoHabitacionRepositorio.findAll();
    }

    @Transactional
    @Override
    public void save(TipoHabitacion tipoHabitacion) {
        tipoHabitacionRepositorio.save(tipoHabitacion);
    }

    @Transactional(readOnly = true)
    @Override
    public TipoHabitacion findOne(Long id) {
        return tipoHabitacionRepositorio.findById(id).orElse(null);
    }

    @Transactional
    @Override
    public void delete(Long id) {
        tipoHabitacionRepositorio.deleteById(id);
    }
}
