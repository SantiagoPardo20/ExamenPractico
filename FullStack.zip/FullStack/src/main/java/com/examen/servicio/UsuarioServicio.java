package com.examen.servicio;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.examen.modelo.Usuario;


public interface UsuarioServicio extends UserDetailsService{
	public List<Usuario> listarUsuarios();
	

    
    boolean existePorEmail(String email);
	
}
