package com.examen.servicio;

import java.util.List;
import com.examen.modelo.Habitacion;


public interface IHabitacionService {
 List<Habitacion> findAll();
 List<Habitacion> findByBusqueda(int numhabitacion, String tipoNombre, String estado, Double precio);
 void save(Habitacion habitacion);
 Habitacion findOne(Long id);
 void delete(Long id);
}
