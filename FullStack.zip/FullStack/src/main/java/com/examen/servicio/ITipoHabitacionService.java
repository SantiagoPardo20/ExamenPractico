package com.examen.servicio;

import java.util.List;

import com.examen.modelo.TipoHabitacion;

public interface ITipoHabitacionService {
    public List<TipoHabitacion> findAll();
    public void save(TipoHabitacion tipoHabitacion);
    public TipoHabitacion findOne(Long id);
    public void delete(Long id);
}
