package com.examen.controlador;

import java.io.ByteArrayInputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.modelo.Habitacion;
import com.examen.servicio.HabitacionServiceImpl;


@RestController
public class ReporteController {

    @Autowired
    private com.examen.servicio.ReporteService reporteService;

    @Autowired
    private HabitacionServiceImpl habitacionServiceImpl;

    @GetMapping("/admin/reportepdf")
    public ResponseEntity<InputStreamResource> generarReporte() {
        List<Habitacion> habitacions = habitacionServiceImpl.findAll();
        ByteArrayInputStream bis = reporteService.generarReporte(habitacions);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=reporte_productos.pdf");

        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
    }
}
