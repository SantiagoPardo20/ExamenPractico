package com.examen.controlador;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.examen.modelo.Habitacion;
import com.examen.modelo.TipoHabitacion;
import com.examen.servicio.IHabitacionService;
import com.examen.servicio.ITipoHabitacionService;

@Controller
@SessionAttributes("habitacion")
@RequestMapping("/web")
public class HabitacionController {

	 @Autowired
	    private IHabitacionService habitacionService;

	    @Autowired
	    private ITipoHabitacionService tipoHabitacionService;

	    @GetMapping("/listar")
	    public String listar(Model model) {
	        model.addAttribute("titulo", "Gestionar Habitaciones");
	        model.addAttribute("habitaciones", habitacionService.findAll());
	        return "web/listar";
	    }

	    @GetMapping("/form")
	    public String crear(Model model) {
	        Habitacion habitacion = new Habitacion();
	        List<TipoHabitacion> tipos = tipoHabitacionService.findAll();
	        model.addAttribute("habitacion", habitacion);
	        model.addAttribute("tipos", tipos); // Agregar los tipos al modelo
	        model.addAttribute("titulo", "Formulario de Habitaciones");
	        return "web/form";
	    }

	    @PostMapping("/form")
	    public String guardar(Habitacion habitacion, RedirectAttributes flash) {
	        String mensajeFlash = (habitacion.getId() != null) ? "La habitación se ha editado con éxito" : "La habitación se ha creado con éxito";
	        habitacionService.save(habitacion);
	        flash.addFlashAttribute("success", mensajeFlash);
	        return "redirect:/web/listar";
	    }

	    @GetMapping("/form/{id}")
	    public String editar(@PathVariable(value = "id") Long id, Model model, RedirectAttributes flash) {
	        Habitacion habitacion = habitacionService.findOne(id);
	        if (habitacion == null) {
	            flash.addFlashAttribute("error", "La habitación no existe en la base de datos");
	            return "redirect:/web/listar";
	        }
	        List<TipoHabitacion> tipos = tipoHabitacionService.findAll();
	        model.addAttribute("habitacion", habitacion);
	        model.addAttribute("tipos", tipos); // Agregar los tipos al modelo
	        model.addAttribute("titulo", "Editar Habitación");
	        return "web/form";
	    }

	    @GetMapping("/eliminar/{id}")
	    public String eliminar(@PathVariable("id") Long id, RedirectAttributes flash) {
	        if (id > 0) {
	            habitacionService.delete(id);
	            flash.addFlashAttribute("success", "Habitación eliminada con éxito");
	        }
	        return "redirect:/web/listar";
	    }

	    @GetMapping("/inventario")
	    public String buscar(
	        @RequestParam(name = "numhabitacion", required = false) String numhabitacionStr,
	        @RequestParam(name = "tipo", required = false) String tipo,
	        @RequestParam(name = "precio", required = false) String precioStr,
	        @RequestParam(name = "estado", required = false) String estado,
	        Model model
	    ) {
	        int numhabitacion = (numhabitacionStr != null && !numhabitacionStr.isEmpty()) ? Integer.parseInt(numhabitacionStr) : 0;
	        Double precio = (precioStr != null && !precioStr.isEmpty()) ? Double.parseDouble(precioStr) : null;

	        List<Habitacion> habitaciones = habitacionService.findByBusqueda(numhabitacion, tipo, estado, precio);
	        List<TipoHabitacion> tipos = tipoHabitacionService.findAll();
	        model.addAttribute("habitaciones", habitaciones);
	        model.addAttribute("tipos", tipos);
	        model.addAttribute("numhabitacion", numhabitacionStr);
	        model.addAttribute("tipo", tipo);
	        model.addAttribute("precio", precioStr);
	        model.addAttribute("estado", estado);
	        model.addAttribute("titulo", "Buscar Habitaciones");
	        return "web/inventario";
	    }

}

