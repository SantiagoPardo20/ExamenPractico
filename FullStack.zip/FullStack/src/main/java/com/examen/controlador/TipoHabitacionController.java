package com.examen.controlador;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.examen.modelo.Habitacion;
import com.examen.modelo.TipoHabitacion;
import com.examen.servicio.IHabitacionService;
import com.examen.servicio.ITipoHabitacionService;

@Controller
@SessionAttributes("tipo_habitacion")
@RequestMapping("/tipo")
public class TipoHabitacionController {

    @Autowired
    private ITipoHabitacionService tipoHabitacionService;

    @GetMapping("/listar")
    public String listar(Model model) {
        model.addAttribute("titulo", "Gestionar Tipos de Habitaciones");
        model.addAttribute("tiposHabitacion", tipoHabitacionService.findAll());
        return "tipo/listar";
    }

    @GetMapping("/form")
    public String crear(Map<String, Object> model) {
        TipoHabitacion tipoHabitacion = new TipoHabitacion();
        model.put("tipo", tipoHabitacion);
        model.put("titulo", "Formulario de Tipo de Habitaciones");
        return "tipo/form";
    }

    @PostMapping("/form")
    public String guardar(TipoHabitacion tipoHabitacion, RedirectAttributes flash) {
        String mensajeFlash = (tipoHabitacion.getId() != null) ? "El tipo de habitación se ha editado con éxito" : "El tipo de habitación se ha creado con éxito";
        tipoHabitacionService.save(tipoHabitacion);
        flash.addFlashAttribute("success", mensajeFlash);
        return "redirect:/tipo/listar";
    }

    @GetMapping("/form/{id}")
    public String editar(@PathVariable(value = "id") Long id, Map<String, Object> model, RedirectAttributes flash) {
        TipoHabitacion tipoHabitacion = tipoHabitacionService.findOne(id);
        if (tipoHabitacion == null) {
            flash.addFlashAttribute("error", "El tipo de habitación no existe en la base de datos");
            return "redirect:/tipo/listar";
        }
        model.put("tipo", tipoHabitacion);
        model.put("titulo", "Editar Tipo de Habitación");
        return "tipo/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable("id") Long id, RedirectAttributes flash) {
        if (id > 0) {
            tipoHabitacionService.delete(id);
            flash.addFlashAttribute("success", "Tipo de habitación eliminado con éxito");
        }
        return "redirect:/tipo/listar";
    }
}