package com.examen.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examen.modelo.Habitacion;
import com.examen.modelo.TipoHabitacion;

public interface TipoHabitacionRepository extends JpaRepository<TipoHabitacion, Long> {
}
