package com.examen.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examen.modelo.Habitacion;
import com.examen.modelo.TipoHabitacion;


public interface HabitacionRepository extends JpaRepository<Habitacion, Long> {
 List<Habitacion> findByNumhabitacionAndTipoNombreContainingIgnoreCaseAndEstadoContainingIgnoreCaseAndPrecio(int numhabitacion, String tipoNombre, String estado, Double precio);
 List<Habitacion> findByNumhabitacion(int numhabitacion);
 List<Habitacion> findByTipoNombreContainingIgnoreCase(String tipoNombre);
 List<Habitacion> findByEstadoContainingIgnoreCase(String estado);
 List<Habitacion> findByPrecio(Double precio);
}
