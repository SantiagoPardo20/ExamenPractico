package com.registro.usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.examen.RegistroUsuariosSpringSecurityApplication;

@SpringBootTest(classes = RegistroUsuariosSpringSecurityApplication.class)
class RegistroUsuariosSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
